import ThemeToggle from "../components/ThemeToggle.jsx";
import StarBackground from "../components/Starbackground.jsx";

const Home = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Theme toggle */}
      <ThemeToggle />

      {/* Background Effects */}
      <StarBackground />
      {/* Navbar */}

      {/* Main Content */}

      {/* footer */}
    </div>
  );
};

export default Home;
