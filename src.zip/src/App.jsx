import Home from './pages/Home.jsx'
import './App.css'


function App() {

  return (
    <>
      <Home></Home>
    </>
  )
}

export default App
